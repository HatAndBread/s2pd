// TODO: Make this.

export function gifToSprite() {

}