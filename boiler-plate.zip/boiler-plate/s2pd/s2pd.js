import * as s from './index.js'
export default s;